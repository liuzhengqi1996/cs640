public interface Runnable {
  public void run();
}
